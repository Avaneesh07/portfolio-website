import React from 'react';
import { ExperienceItem, ProjectItem, EducationItem, SkillCategory, SocialLink } from './types';

export const EXPERIENCE_DATA: ExperienceItem[] = [
  {
    title: 'Photographer & Photo Technician & Sales Associate',
    company: 'Viktorianna Photography',
    period: 'May 2024 - Present',
    location: 'Dallas-Fort Worth',
    points: [
      'Captured and edited high-quality portraits using Photoshop & Lightroom',
      'Managed lighting, cameras, printers for same-day print delivery',
      'Increased photo package conversions through sales & upselling',
      'Calibrated hardware and troubleshot equipment efficiently',
    ],
  },
  {
    title: 'UI/UX Technical Artist',
    company: 'Skillo',
    period: 'Jan 2024 - Present',
    location: 'Hybrid',
    points: [
      'Designed artist-friendly UI/UX systems for real-time production',
      'Built custom Python tool panels using PySide & NumPy',
      'Developed physics sandbox in Pygame + NumPy',
      'Integrated & optimized assets in Unity & Unreal Engine',
      'Created procedural Houdini systems for VFX assets',
    ],
  },
  {
    title: 'Photographer & Photo Technician',
    company: 'Visenta Studio LLC',
    period: 'May 2023 - Nov 2023',
    location: 'Dallas-Fort Worth',
    points: [
      'Captured studio & event photography with professional lighting',
      'Exceeded daily sales goals through customer engagement',
      'Optimized darkroom & digital workflows for efficiency',
    ],
  },
   {
    title: 'Teaching Assistant',
    company: 'University of Texas at Arlington',
    period: 'Aug - Dec 2022',
    location: 'Arlington, TX',
    points: [
      'Supported lectures, labs, and hands-on exercises',
      'Tutored students and graded assignments',
      'Developed supplementary learning materials',
    ],
  },
  {
    title: 'Technical Artist - Amazon Games: New World',
    company: 'Amazon',
    period: 'Jun 2020 - Nov 2021',
    location: 'Hyderabad, India',
    points: [
      'Built custom Python Maya tools, automated tasks by 30%',
      'Created optimized 3D assets in Unity, Maya, Blender',
      'Developed procedural Houdini environments',
      'Integrated Substance workflows for PBR materials',
      'Improved runtime performance & authored tech docs',
    ],
  },
];

export const PROJECTS_DATA: ProjectItem[] = [
  {
    title: 'Physics Sim: Bouncing Ball (Pygame + NumPy)',
    description: 'Interactive real-time physics sandbox merging VFX principles and animation programming. Implemented gravity, collisions, soft-body simulation, spark particles, velocity heatmaps, and real-time debug HUD. Built from scratch to showcase technical art and simulation design.',
    tags: ['Python', 'NumPy', 'Pygame', 'VFX'],
  },
  {
    title: 'Amazon Games - New World Technical Art',
    description: 'Designed and maintained art tools supporting production workflows. Developed custom Python-based Maya tools that automated repetitive tasks, improving efficiency by 30%. Created optimized 3D assets using Unity, Maya, Blender, and Houdini procedural systems.',
    tags: ['Maya', 'Python', 'Unity', 'Houdini'],
  },
  {
    title: 'Gesture Recognition Dynamics',
    description: 'Built a hybrid LSTM-CNN model for video activity detection. Integrated MediaPipe for pose extraction and applied preprocessing to reduce noise. Improved classification speed by 25% and enhanced model accuracy through thorough benchmarking.',
    tags: ['Deep Learning', 'Python', 'LSTM-CNN', 'MediaPipe'],
  },
  {
    title: 'Smart Student Portal',
    description: 'Built single-page academic portal using ReactJS and Spring Boot. Implemented REST APIs, MySQL/H2 database, responsive styling, and role-based user support. Optimized React rendering for 30% faster load times and 40% higher engagement.',
    tags: ['ReactJS', 'Spring Boot', 'MySQL', 'REST API'],
  },
  {
    title: 'MARS Outdoor - 3D Advertising Venture',
    description: 'Creative business & 3D advertising venture featuring mobile LED truck ads, 3D hologram signage, and futuristic outdoor advertising. Created 3D animations for LED trucks, hologram ads, and brand identity materials using AI tools.',
    tags: ['3D Animation', 'Blender', 'After Effects', 'Premiere Pro', 'AI Tools'],
  },
  {
    title: 'Lucid Origin - AI Film Project',
    description: 'Experimental AI film and animation project focused on AI-driven storytelling. Created cinematic VFX portfolio piece blending AI with technical art. Developed experimental 3D assembly visuals, camera motion, and lighting experiments.',
    tags: ['AI Animation', 'Blender', 'Unreal Engine', 'VFX'],
  },
];

export const EDUCATION_DATA: EducationItem[] = [
    {
        degree: 'MS, Computer Science',
        university: 'University of Texas at Arlington',
        period: 'Jan 2022 - Dec 2023',
        gpa: '3.7',
        courses: ['Machine Learning', 'Computer Vision', 'Data Mining', 'Advanced Algorithms'],
        activities: 'ACM, HackUTA, AI/ML Study Groups, Council, open-source contributor',
    },
    {
        degree: 'BTech, Computer Science',
        university: 'GITAM Deemed University',
        period: 'Aug 2016 - Sep 2020',
        gpa: '3.2',
        courses: ['Data Structures', 'Algorithms', 'Object-Oriented Programming', 'Database Management'],
        activities: 'Coding Club, Hackathons, Tech Fest, Google DSC',
    }
]

export const SKILLS_DATA: SkillCategory[] = [
  {
    title: '3D Software & Game Engines',
    skills: ['Maya', 'Blender', 'Unity', 'Unreal Engine', 'Houdini', 'Substance'],
  },
  {
    title: 'Programming & Automation',
    skills: ['Python', 'C++', 'NumPy', 'PySide', 'Maya.cmds', 'Pygame', 'ReactJS', 'Spring Boot'],
  },
  {
    title: 'Photography & Visual Arts',
    skills: ['Photoshop', 'Lightroom', 'After Effects', 'Premiere Pro', 'Illustrator', 'Photography', 'Lighting', 'VFX'],
  },
  {
    title: 'Generative AI Tools',
    skills: ['Ideogram AI', 'Leonardo AI', 'Akool AI', 'Adobe Firefly', 'Pika Labs', 'Runway Gen-2', 'Kaiber AI', 'Synthesia', 'HeyGen', 'CapCut', 'Meshy AI', 'Tripo AI', 'Spline 3D', 'Luma AI', 'ElevenLabs', 'ChatGPT', 'Claude', 'Gemini'],
  },
];

export const SOCIAL_LINKS_DATA: SocialLink[] = [
    {
        name: 'LinkedIn',
        handle: 'Professional Profile',
        url: 'https://www.linkedin.com/in/avaneesh-muddasani-55b497189',
        icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>
    },
    {
        name: 'GitHub',
        handle: 'Code & Projects',
        url: 'https://github.com/Avaneesh07',
        icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2A10 10 0 0 0 2 12c0 4.42 2.87 8.17 6.84 9.5.5.08.66-.23.66-.5v-1.69c-2.77.6-3.36-1.34-3.36-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.87 1.52 2.34 1.07 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.92 0-1.11.38-2 1.03-2.71-.1-.25-.45-1.29.1-2.64 0 0 .84-.27 2.75 1.02.79-.22 1.65-.33 2.5-.33.85 0 1.71.11 2.5.33 1.91-1.29 2.75-1.02 2.75-1.02.55 1.35.2 2.39.1 2.64.65.71 1.03 1.6 1.03 2.71 0 3.82-2.34 4.66-4.57 4.91.36.31.69.92.69 1.85V21c0 .27.16.59.67.5C19.14 20.16 22 16.42 22 12A10 10 0 0 0 12 2z"/></svg>
    },
    {
        name: 'Email',
        handle: 'muddasaniavaneeshreddy@gmail.com',
        url: 'mailto:muddasaniavaneeshreddy@gmail.com',
        icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
    },
    {
        name: 'Phone',
        handle: '+1 (214) 869-8949',
        url: 'tel:+12148698949',
        icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
    }
];

// FIX: Added CHATBOT_SYSTEM_INSTRUCTION for the AI assistant in Chatbot.tsx
export const CHATBOT_SYSTEM_INSTRUCTION = `You are a creative AI assistant for Avaneesh Muddasani, a Technical Artist & UI/UX Designer.
Your purpose is to answer questions about Avaneesh's portfolio, skills, and experience in a helpful, professional, and engaging manner.
You are knowledgeable about his work in 3D pipelines, real-time tools, Python automation, VFX, game development, and generative AI.
Refer to his experience at Amazon Games on 'New World', his physics simulations, gesture recognition models, and other projects.
Keep your responses concise and focused on his professional work. Do not invent information. If you don't know something, say you don't have that information.
The goal is to provide a helpful overview to potential recruiters, collaborators, or anyone interested in his work.`;
