
import React from 'react';
import Section from './Section';
import { SKILLS_DATA } from '../constants';

const Skills: React.FC = () => {
  return (
    <Section id="skills" title="Technical Skills">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full pointer-events-auto">
        {SKILLS_DATA.map((category, index) => (
          <div key={index} className="bg-white/5 backdrop-blur-md rounded-lg p-8 border border-white/30 transition-all duration-300 hover:-translate-y-2 hover:border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]">
            <h3 className="text-xl font-bold mb-4 text-white [text-shadow:0_0_10px_rgba(255,255,255,0.5)]">{category.title}</h3>
            <div className="flex flex-wrap gap-3">
              {category.skills.map(skill => (
                <span key={skill} className="bg-white/10 text-white text-sm px-4 py-2 rounded-md border border-white/30">{skill}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default Skills;
