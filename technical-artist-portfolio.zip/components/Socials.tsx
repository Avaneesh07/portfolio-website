
import React from 'react';
import Section from './Section';
import { SOCIAL_LINKS_DATA } from '../constants';

const Socials: React.FC = () => {
    return (
        <Section id="social" title="Connect With Me" minHeight="min-h-[50vh]">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto w-full pointer-events-auto">
                {SOCIAL_LINKS_DATA.map((link) => (
                     <a 
                        key={link.name}
                        href={link.url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="bg-white/5 backdrop-blur-md rounded-lg p-8 border border-white/30 text-white no-underline flex flex-col items-center text-center transition-all duration-300 hover:-translate-y-2 hover:border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]"
                    >
                        <div className="mb-4">{link.icon}</div>
                        <h3 className="text-xl font-bold mb-2 [text-shadow:0_0_10px_rgba(255,255,255,0.5)]">{link.name}</h3>
                        <p className="text-sm text-white/70">{link.handle}</p>
                    </a>
                ))}
            </div>
        </Section>
    );
};

export default Socials;
