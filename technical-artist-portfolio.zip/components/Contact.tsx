
import React, { useState } from 'react';
import Section from './Section';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you for your message, ${formData.name}! I'll get back to you soon at ${formData.email}.`);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <Section id="contact" title="Get In Touch">
      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto w-full pointer-events-auto">
        <div className="mb-6">
          <label htmlFor="name" className="block mb-2 text-white">Name</label>
          <input 
            type="text" 
            id="name" 
            name="name" 
            value={formData.name}
            onChange={handleChange}
            required 
            className="w-full p-4 bg-black/80 border border-white/30 rounded-lg text-white focus:outline-none focus:border-white focus:shadow-[0_0_20px_rgba(255,255,255,0.5)] transition-all"
          />
        </div>
        <div className="mb-6">
          <label htmlFor="email" className="block mb-2 text-white">Email</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            value={formData.email}
            onChange={handleChange}
            required 
            className="w-full p-4 bg-black/80 border border-white/30 rounded-lg text-white focus:outline-none focus:border-white focus:shadow-[0_0_20px_rgba(255,255,255,0.5)] transition-all"
          />
        </div>
        <div className="mb-6">
          <label htmlFor="message" className="block mb-2 text-white">Message</label>
          <textarea 
            id="message" 
            name="message" 
            value={formData.message}
            onChange={handleChange}
            required 
            rows={6}
            className="w-full p-4 bg-black/80 border border-white/30 rounded-lg text-white resize-vertical min-h-[150px] focus:outline-none focus:border-white focus:shadow-[0_0_20px_rgba(255,255,255,0.5)] transition-all"
          ></textarea>
        </div>
        <button 
          type="submit" 
          className="w-full py-4 px-10 bg-white text-black no-underline font-semibold rounded-md border-2 border-white shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-300 ease-in-out hover:transform hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(255,255,255,0.8),_0_10px_30px_rgba(255,255,255,0.4)] hover:bg-black hover:text-white"
        >
          Send Message
        </button>
      </form>
    </Section>
  );
};

export default Contact;
