
import React from 'react';

interface SectionProps {
  id: string;
  title: string;
  children: React.ReactNode;
  minHeight?: string;
}

const Section: React.FC<SectionProps> = ({ id, title, children, minHeight = "min-h-screen" }) => {
  return (
    <section id={id} className={`flex items-center p-[5%] ${minHeight}`}>
      <div className="w-full">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-12 text-center w-full [text-shadow:0_0_20px_rgba(255,255,255,0.5)]">
          {title}
        </h2>
        {children}
      </div>
    </section>
  );
};

export default Section;
