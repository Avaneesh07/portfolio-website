import React from 'react';
import Section from './Section';
import { PROJECTS_DATA } from '../constants';

const Projects: React.FC = () => {
  return (
    <Section id="projects" title="Featured Projects">
      <div className="flex flex-col items-center w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 w-full pointer-events-auto">
          {PROJECTS_DATA.map((project, index) => (
            <div key={index} className="bg-white/5 backdrop-blur-md rounded-lg p-8 border border-white/30 transition-all duration-300 hover:-translate-y-2 hover:border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] flex flex-col">
              <h3 className="text-xl font-bold mb-2 text-white [text-shadow:0_0_10px_rgba(255,255,255,0.5)]">{project.title}</h3>
              <p className="text-white/70 line-clamp-4 flex-grow">{project.description}</p>
              <div className="flex flex-wrap gap-2 mt-4">
                {project.tags.map(tag => (
                  <span key={tag} className="bg-white/10 text-white text-sm px-3 py-1 rounded-md border border-white/30">{tag}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
        <a 
          href="https://github.com/Avaneesh07?tab=repositories"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-12 inline-block w-fit py-4 px-10 bg-white text-black no-underline font-semibold rounded-md border-2 border-white shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-300 ease-in-out hover:transform hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(255,255,255,0.8),_0_10px_30px_rgba(255,255,255,0.4)] hover:bg-black hover:text-white pointer-events-auto"
        >
          View All Creative Work
        </a>
      </div>
    </Section>
  );
};

export default Projects;