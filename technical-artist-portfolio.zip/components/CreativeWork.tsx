import React from 'react';
import Section from './Section';

const CreativeWork: React.FC = () => {
  return (
    <Section id="creative-work" title="My Creative Work">
      <div className="text-center max-w-3xl mx-auto pointer-events-auto">
        <p className="text-lg sm:text-xl md:text-2xl mb-8 text-white/80">
          For a deeper dive into my creative process, technical breakdowns, and a full showcase of my work, please visit my GitHub profile, which serves as my primary portfolio.
        </p>
        <a 
          href="https://github.com/Avaneesh07?tab=repositories"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block w-fit py-4 px-10 bg-white text-black no-underline font-semibold rounded-md border-2 border-white shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-300 ease-in-out hover:transform hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(255,255,255,0.8),_0_10px_30px_rgba(255,255,255,0.4)] hover:bg-black hover:text-white"
        >
          Explore My Work on GitHub
        </a>
      </div>
    </Section>
  );
};

export default CreativeWork;
