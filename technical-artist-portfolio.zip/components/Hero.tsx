
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="h-screen flex flex-col justify-center px-[5%] pointer-events-auto">
      <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-4 text-white [text-shadow:0_0_20px_rgba(255,255,255,0.8),_0_0_40px_rgba(255,255,255,0.5)] font-mono tracking-widest whitespace-nowrap">
        AVANEESH MUDDASANI
      </h1>
      <p className="text-lg sm:text-xl md:text-2xl max-w-2xl mb-8 text-white/80">
        Technical Artist & UI/UX Designer specializing in 3D pipelines, real-time tools, Python automation, and VFX. Building art systems that bridge creativity and technology for games and interactive experiences.
      </p>
      <a 
        href="#projects" 
        className="inline-block w-fit py-4 px-10 bg-white text-black no-underline font-semibold rounded-md border-2 border-white shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-300 ease-in-out hover:transform hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(255,255,255,0.8),_0_10px_30px_rgba(255,255,255,0.4)] hover:bg-black hover:text-white"
      >
        View My Work
      </a>
    </section>
  );
};

export default Hero;
