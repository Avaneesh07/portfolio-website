import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';
import Section from './Section';
import { CHATBOT_SYSTEM_INSTRUCTION } from '../constants';
import type { ChatMessage } from '../types';

const Chatbot: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { sender: 'bot', text: "Hello! I'm Avaneesh's creative AI assistant. Ask me anything about his work." }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatRef = useRef<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const initChat = async () => {
            try {
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
                chatRef.current = ai.chats.create({
                    model: 'gemini-2.5-flash',
                    config: {
                        systemInstruction: CHATBOT_SYSTEM_INSTRUCTION,
                    },
                });
            } catch (error) {
                console.error("Failed to initialize chatbot:", error);
                setMessages(prev => [...prev, { sender: 'bot', text: "Sorry, I'm having trouble connecting right now." }]);
            }
        };
        initChat();
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;
        
        const userMessage: ChatMessage = { sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            if (!chatRef.current) {
                throw new Error("Chat not initialized");
            }
            const response = await chatRef.current.sendMessage({ message: input });
            const botMessage: ChatMessage = { sender: 'bot', text: response.text };
            setMessages(prev => [...prev, botMessage]);
        } catch (error) {
            console.error("Chatbot error:", error);
            setMessages(prev => [...prev, { sender: 'bot', text: "I encountered an error. Please try again." }]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Section id="chatbot" title="Ask Me Anything About Avaneesh">
            <div className="max-w-4xl mx-auto w-full pointer-events-auto">
                <div className="bg-white/5 backdrop-blur-md rounded-lg border border-white/30 h-[70vh] flex flex-col">
                    {/* Chat History */}
                    <div className="flex-grow p-6 overflow-y-auto">
                        <div className="space-y-4">
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                                    <div 
                                        className={`max-w-lg px-4 py-2 rounded-xl ${
                                            msg.sender === 'user' 
                                                ? 'bg-white/20 text-white rounded-br-none' 
                                                : 'bg-black/20 text-white/90 rounded-bl-none'
                                        }`}
                                    >
                                        <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                            {isLoading && (
                                <div className="flex justify-start">
                                    <div className="max-w-lg px-4 py-2 rounded-xl bg-black/20 text-white/90 rounded-bl-none flex items-center space-x-2">
                                        <span className="h-2 w-2 bg-white/50 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                        <span className="h-2 w-2 bg-white/50 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                        <span className="h-2 w-2 bg-white/50 rounded-full animate-bounce"></span>
                                    </div>
                                </div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>
                    </div>

                    {/* Input Form */}
                    <div className="p-4 border-t border-white/20">
                        <form onSubmit={handleSubmit} className="flex gap-4">
                            <input
                                type="text"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Ask about my 3D models, VFX, or AI art..."
                                className="w-full p-3 bg-black/80 border border-white/30 rounded-lg text-white focus:outline-none focus:border-white focus:shadow-[0_0_20px_rgba(255,255,255,0.5)] transition-all placeholder:text-white/40"
                                disabled={isLoading}
                                aria-label="Chat input"
                            />
                            <button
                                type="submit"
                                disabled={isLoading || !input.trim()}
                                className="py-3 px-6 bg-white text-black font-semibold rounded-md border-2 border-white shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-300 ease-in-out hover:bg-black hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                                aria-label="Send message"
                            >
                                Send
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </Section>
    );
};

export default Chatbot;