
import React from 'react';
import Section from './Section';
import { EDUCATION_DATA } from '../constants';

const Education: React.FC = () => {
    return (
        <Section id="education" title="Education">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-5xl mx-auto pointer-events-auto">
                {EDUCATION_DATA.map((edu, index) => (
                    <div key={index} className="bg-white/5 backdrop-blur-md rounded-lg p-8 border border-white/30 transition-all duration-300 hover:-translate-y-2 hover:border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]">
                        <h3 className="text-xl font-bold mb-2 text-white [text-shadow:0_0_10px_rgba(255,255,255,0.5)]">{edu.degree}</h3>
                        <p className="font-semibold mb-1">{edu.university}</p>
                        <p className="text-sm text-white/70 mb-2">{edu.period}</p>
                        <p className="text-white/90 mb-4">GPA: {edu.gpa}</p>

                        <p className="font-semibold mb-2">Relevant Coursework:</p>
                        <ul className="list-disc list-inside space-y-1 text-white/70 mb-4">
                            {edu.courses.map((course, i) => <li key={i}>{course}</li>)}
                        </ul>

                        <p className="font-semibold mb-1">Activities:</p>
                        <p className="text-white/70">{edu.activities}</p>
                    </div>
                ))}
            </div>
        </Section>
    );
};

export default Education;
