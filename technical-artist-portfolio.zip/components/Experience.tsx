
import React from 'react';
import Section from './Section';
import { EXPERIENCE_DATA } from '../constants';

const Experience: React.FC = () => {
  return (
    <Section id="experience" title="Professional Experience">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 w-full pointer-events-auto">
        {EXPERIENCE_DATA.map((item, index) => (
          <div key={index} className="bg-white/5 backdrop-blur-md rounded-lg p-8 border border-white/30 transition-all duration-300 hover:-translate-y-2 hover:border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]">
            <h3 className="text-xl font-bold mb-2 text-white [text-shadow:0_0_10px_rgba(255,255,255,0.5)]">{item.title}</h3>
            <p className="font-semibold mb-1">{item.company}</p>
            <p className="text-sm text-white/70 mb-4">{`${item.period} | ${item.location}`}</p>
            <ul className="list-disc list-inside space-y-2 text-white/70">
              {item.points.map((point, i) => <li key={i}>{point}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default Experience;
