import React from 'react';
import Section from './Section';

// FIX: Changed JSX.Element to React.ReactNode to resolve "Cannot find namespace 'JSX'" error on line 5.
const GalleryItem: React.FC<{ title: string; icon: React.ReactNode; }> = ({ title, icon }) => (
  <div className="aspect-square bg-white/5 backdrop-blur-md rounded-lg overflow-hidden border border-white/30 transition-all duration-300 hover:-translate-y-2 hover:border-white hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]">
    <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
      <div className="opacity-60 mb-4">{icon}</div>
      <p className="font-semibold text-white/80">{title}</p>
    </div>
  </div>
);

const Gallery: React.FC = () => {
  const items = [
    { title: '3D Models & Assets', icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14zM5 10h5v7H5zm6-5h8v12h-8z"/></svg> },
    { title: 'AI Generated Images', icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54-1.96-2.36L6.5 17h11l-3.54-4.71z"/></svg> },
    { title: 'Animation & VFX', icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/></svg> },
    { title: 'Technical Pipelines', icon: <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M21 6h-7.59l3.29-3.29L16 2l-4 4-4-4-.71.71L10.59 6H3c-1.1 0-2 .89-2 2v12c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.11-.9-2-2-2zm0 14H3V8h18v12zM9 10v8l7-4z"/></svg> },
  ];

  return (
    <Section id="gallery" title="My Creative Work">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 w-full pointer-events-auto">
        {items.map(item => <GalleryItem key={item.title} {...item} />)}
      </div>
    </Section>
  );
};

export default Gallery;
