import type { ReactNode } from 'react';

export interface ExperienceItem {
  title: string;
  company: string;
  period: string;
  location: string;
  points: string[];
}

export interface ProjectItem {
  title: string;
  description: string;
  tags: string[];
}

export interface EducationItem {
  degree: string;
  university: string;
  period: string;
  gpa: string;
  courses: string[];
  activities: string;
}

export interface SkillCategory {
  title: string;
  skills: string[];
}

export interface SocialLink {
  name: string;
  handle: string;
  url: string;
  // FIX: Changed JSX.Element to ReactNode to resolve "Cannot find namespace 'JSX'" error on line 34.
  icon: ReactNode;
}

// FIX: Added ChatMessage interface to be used in Chatbot.tsx
export interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
}
