import React from 'react';
import ParticleCanvas from './components/ParticleCanvas';
import Hero from './components/Hero';
import ScrollIndicator from './components/ScrollIndicator';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Education from './components/Education';
import Skills from './components/Skills';
import Socials from './components/Socials';
import Contact from './components/Contact';
import Chatbot from './components/Chatbot';

function App() {
  return (
    <div className="bg-black text-white font-sans overflow-x-hidden">
      <ParticleCanvas />
      <div className="relative z-10">
        <main className="pointer-events-none">
          <Hero />
          <ScrollIndicator />
          <Experience />
          <Projects />
          <Education />
          <Chatbot />
          <Skills />
          <Socials />
          <Contact />
        </main>
      </div>
    </div>
  );
}

export default App;